<!--<link href="https://fonts.googleapis.com/css?family=Cantarell|Cutive+Mono" rel="stylesheet">-->
<link rel="stylesheet" type="text/css" href="style/thumbnail.css">