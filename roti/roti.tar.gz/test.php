
<?php include_once 'inc/generics.php' ?>
<?php include_once 'inc/header.php' ?>
<?php include_once 'inc/initThumbnail.php' ?>
<?php include_once 'inc/sidebar.php' ?>


<?php

	readPost(getRecord('*','post','id = 1'));

?>


<?php include_once 'inc/footer.php' ?>

